import 'package:flutter/material.dart';

class AppColors {
  static const Color backgroundColor = Color(0xFF0D152F);
  static const Color black = Color(0xFF000000);
  static const Color iconColor = Color(0xff5F6368);
  static const Color textDarkPrimary = Color(0xFF1C1C1C);
  static const Color textDarkSecondary = Color(0xFF4A4A4A);
  static const Color textDarkTertiary = Color(0xFF515151);
  static const Color textMuted = Color(0xFF777777);
  static const Color textMutedLight = Color(0xFF797979);
  static const Color lightBlueColor = Color(0xffC9F0FF);

  static const Color orangeColor= Color(0xffE9822D);
  static const Color iconColor2= Color(0xFFA3A3A3);
  static const Color buttonOutlineColor = Color(0xFFD9D9D9);
  static const Color green1 = Color(0xff0E7D1F);

  static const Color textFieldColor = Color(0xFFECECEC);
  static const Color textFieldFillColor = Color(0x90D2D2D2);
  static const Color grey = Color(0xFFF3F2F2);
  // Gradient colors
  static const Color gradientStart = Color(0xFF226076);
  static const Color gradientEnd = Color(0xFF0089BA);

  // Border colors
  static const Color hintTextColor = Color(0xFF777777);
  static const Color dividerColor = Color(0xFFF7F7F7);
  static const Color dividerColor2 = Color(0xFFE9E9E9);
  static const Color dividerColor3 = Color(0xFFC9F0FF);

  // Background colors
  static const Color bgColor = Color(0xFFF7F8FA);
  static const Color appBarColor = Color(0xff020523);

  static const Color containerColor = Color(0xffDEE0F6);
  static const Color containerColor2 = Color(0xFFF4F4F4);
  static const Color borderColor = Color(0xffCFCFCF);

  static const Color buttonColor2 = Color(0x33CBA033);

  // Button colors
  static const Color white1 = Color(0xFFFFFFFF);
  static const Color white2 = Color(0xFFFDFDFD);

  static const Color red = Color(0xFFDD3737);
  static const Color darkRed = Color(0xFFB71C1C );
  static const Color yellow = Color(0xFFFBB914);
  static const Color green = Color(0xFF22C55E);
  static const Color darkBlue = Color(0xFF0C4C84);


  static const Color barColor1 = Color(0xAFFB3714);
  static const Color barColor3 = Color(0xFFFF8C1A);
  static const Color barColor4 = Color(0xFF4CAC39);
  static const Color barColor5 = Color(0xFF5D7FF5);
  static const Color barColor6 = Color(0xFFF8D895);
  static const Color barColor7 = Color(0xFF8DF5AA);
}
