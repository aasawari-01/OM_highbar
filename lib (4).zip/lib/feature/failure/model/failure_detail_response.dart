import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../../../core/models/label_value.dart';

class FailureDetailResponse {
  final int? responseCode;
  final String? responseMessage;
  final FailureDetailOutput? responseOutput;
  final String? failureRectificationJson;

  FailureDetailResponse({
    this.responseCode,
    this.responseMessage,
    this.responseOutput,
    this.failureRectificationJson,
  });

  factory FailureDetailResponse.fromJson(Map<String, dynamic> json) {
    String? rcaJson;
    final rcaValue = json['FailureRectificationJson'];
    if (rcaValue != null) {
      if (rcaValue is String) {
        rcaJson = rcaValue;
      } else if (rcaValue is List) {
        rcaJson = jsonEncode(rcaValue);
      }
    }

    return FailureDetailResponse(
      responseCode: json['responseCode'] as int?,
      responseMessage: json['responseMessage'] as String?,
      responseOutput: json['responseOutput'] != null
          ? FailureDetailOutput.fromJson(json['responseOutput'] as Map<String, dynamic>)
          : null,
      failureRectificationJson: rcaJson,
    );
  }
}

class FailureDetailOutput {
  final List<LabelValue>? getNotificationTypeList;
  final List<LabelValue>? getNatureOfWorkList;
  final List<LabelValue>? getDepartmentList;
  final List<LabelValue>? getUserList;
  final List<LabelValue>? getEquipmentList;
  final List<LabelValue>? getObjectData;
  final List<LabelValue>? getMaterialData;
  final List<LabelValue>? getUserStatus;
  final List<LabelValue>? getLocationTypeList;
  final List<LabelValue>? getStorageLocation;
  final List<LabelValue>? getPriorityType;
  final List<LabelValue>? getCorrNotificationTypeList;
  final List<LabelValue>? getFaultData;
  final List<LabelValue>? getReasonForDelayList;
  final List<NotificationActionHistory>? getNotificationActionUserHistory;
  final List<NotificationHistory>? getNotificationHistory;
  final List<LabelValue>? getFunctionalLocationList;
  final List<LabelValue>? getEquipmentDetails;
  final List<LabelValue>? getRootCausetData;
  final List<LabelValue>? getActionData;
  final List<Map<String, dynamic>>? measurementPoint;
  final CreateVMModel? getCreateVMModel;
  final List<Map<String, dynamic>>? getObjectANDFaultList;
  final List<Map<String, dynamic>>? getObjectANDFaultActionList;
  final List<Map<String, dynamic>>? getObjectANDFaultRootCauseList;
  final List<Map<String, dynamic>>? getMaterialReqDetails;
  final List<Map<String, dynamic>>? getMaterialDismantleDetails;
  final List<Map<String, dynamic>>? getImageBefor;
  final List<Map<String, dynamic>>? getJoinInspectionHistory;

  FailureDetailOutput({
    this.getNotificationTypeList,
    this.getNatureOfWorkList,
    this.getDepartmentList,
    this.getUserList,
    this.getEquipmentList,
    this.getObjectData,
    this.getMaterialData,
    this.getUserStatus,
    this.getLocationTypeList,
    this.getStorageLocation,
    this.getPriorityType,
    this.getCorrNotificationTypeList,
    this.getFaultData,
    this.getReasonForDelayList,
    this.getNotificationActionUserHistory,
    this.getNotificationHistory,
    this.getFunctionalLocationList,
    this.getEquipmentDetails,
    this.getRootCausetData,
    this.getActionData,
    this.measurementPoint,
    this.getCreateVMModel,
    this.getObjectANDFaultList,
    this.getObjectANDFaultActionList,
    this.getObjectANDFaultRootCauseList,
    this.getMaterialReqDetails,
    this.getMaterialDismantleDetails,
    this.getImageBefor,
    this.getJoinInspectionHistory,
  });

  factory FailureDetailOutput.fromJson(Map<String, dynamic> json) {
    return FailureDetailOutput(
      getNotificationTypeList: _mapList(json['getNotificationTypeList']),
      getNatureOfWorkList: _mapList(json['getNatureOfWorkList']),
      getDepartmentList: _mapList(json['getDepartmentList'] ?? json['department']),
      getUserList: _mapList(json['getUserList'] ?? json['getAssgineUserList'] ?? json['personResponsible']),
      getEquipmentList: _mapList(json['getEquipmentList'] ?? json['getEquipmentNoList'] ?? json['equipment']),
      getObjectData: _mapList(json['getObjectData'] ?? json['objectPart']),
      getMaterialData: _mapList(json['getMaterialData'] ?? json['materialCode']),
      getUserStatus: _mapList(json['getUserStatus'] ?? json['status']),
      getLocationTypeList: _mapList(json['getLocationTypeList']),
      getStorageLocation: _mapList(json['getStorageLocation']),
      getPriorityType: _mapList(json['getPriorityType']),
      getCorrNotificationTypeList: _mapList(json['getCorrNotificationTypeList']),
      getFaultData: _mapList(json['getFaultData']),
      getReasonForDelayList: _mapList(json['getReasonForDelayList']),
      getRootCausetData: _mapList(json['getRootCausetData']),
      getActionData: _mapList(json['getActionData']),
      getFunctionalLocationList: _mapList(json['getFunctionalLocationList'] ?? json['getFunctionLocList'] ?? json['functionalLocation']),
      getEquipmentDetails: _mapList(json['getEquipmentDetails']),
      measurementPoint: json['measurementPoint'] != null
          ? (json['measurementPoint'] as List).map((e) => e as Map<String, dynamic>).toList()
          : null,

      getNotificationActionUserHistory: json['getNotificationActionUserHistory'] != null
          ? (json['getNotificationActionUserHistory'] as List)
          .map((e) => NotificationActionHistory.fromJson(e as Map<String, dynamic>))
          .toList()
          : null,

      getNotificationHistory: json['getNotificationHistory'] != null
          ? (json['getNotificationHistory'] as List)
          .map((e) => NotificationHistory.fromJson(e as Map<String, dynamic>))
          .toList()
          : null,
      getCreateVMModel: _parseCreateVm(json),
      getObjectANDFaultList: (json['getObjectANDFaultList'] ?? json['failureRectificationDetails']) != null
          ? List<Map<String, dynamic>>.from(json['getObjectANDFaultList'] ?? json['failureRectificationDetails'])
          : null,
      getObjectANDFaultActionList: (json['getObjectANDFaultActionList'] ?? json['failureActionDetails']) != null
          ? List<Map<String, dynamic>>.from(json['getObjectANDFaultActionList'] ?? json['failureActionDetails'])
          : null,
      getObjectANDFaultRootCauseList: (json['getObjectANDFaultRootCauseList'] ?? json['failureRootCauseDetails']) != null
          ? List<Map<String, dynamic>>.from(json['getObjectANDFaultRootCauseList'] ?? json['failureRootCauseDetails'])
          : null,
      getMaterialReqDetails: json['getMaterialReqDetails'] != null
          ? (json['getMaterialReqDetails'] as List).map((e) => e as Map<String, dynamic>).toList()
          : null,
      getMaterialDismantleDetails: json['getMaterialDismantleDetails'] != null
          ? (json['getMaterialDismantleDetails'] as List).map((e) => e as Map<String, dynamic>).toList()
          : null,
      getImageBefor: json['getImageBefor'] != null
          ? List<Map<String, dynamic>>.from(json['getImageBefor'])
          : null,
      getJoinInspectionHistory: (json['joinInspectionHistory'] ??
          json['getJointInspectionHistory'] ??
          json['JoinInspectionHistory']) !=
          null
          ? List<Map<String, dynamic>>.from(json['getJoinInspectionHistory'] ??
          json['joinInspectionHistory'] ??
          json['getJointInspectionHistory'] ??
          json['JoinInspectionHistory'])
          : null,
    );
  }

  static CreateVMModel? _parseCreateVm(Map<String, dynamic> json) {
    dynamic raw;
    for (final e in json.entries) {
      final k = e.key.toString().toLowerCase();
      if (k == 'getcreatevmmodel' || k == 'createvmmodel') {
        raw = e.value;
        break;
      }
    }

    // Fallback: the model may be flat inside responseOutput
    if (raw == null && json.containsKey('notificationId')) {
      raw = json;
    }

    if (raw == null) return null;
    if (raw is String && raw.trim().isNotEmpty) raw = jsonDecode(raw);
    if (raw is List && raw.isNotEmpty) raw = raw.first;
    if (raw is Map) {
      return CreateVMModel.fromJson(Map<String, dynamic>.from(raw));
    }
    return null;
  }
}



class NotificationActionHistory {
  final int? notificationId;
  final int? assgineUserId;
  final int? statusId;

  final String? statusName;
  final String? remark;

  final int? createdBy;
  final String? actionBy;
  final String? actionOn;

  final String? assginedUserName;

  final int? updatedUserId;
  final String? updatedUserName;
  final String? updatedOn;

  NotificationActionHistory({
    this.notificationId,
    this.assgineUserId,
    this.statusId,
    this.statusName,
    this.remark,
    this.createdBy,
    this.actionBy,
    this.actionOn,
    this.assginedUserName,
    this.updatedUserId,
    this.updatedUserName,
    this.updatedOn,
  });

  factory NotificationActionHistory.fromJson(
      Map<String, dynamic> json) {
    return NotificationActionHistory(
      notificationId: json['notificationId'] as int?,
      assgineUserId: json['assgineUserId'] as int?,
      statusId: json['statusId'] as int?,

      statusName: json['statusName']?.toString(),
      remark: json['remark']?.toString(),

      // createdBy is a number in API response
      createdBy: json['createdBy'] as int?,

      // actionBy is a String in API response
      actionBy: json['actionBy']?.toString(),

      actionOn: json['actionOn']?.toString(),

      assginedUserName: json['assginedUserName']?.toString(),

      updatedUserId: json['updatedUserId'] as int?,
      updatedUserName: json['updatedUserName']?.toString(),
      updatedOn: json['updatedOn']?.toString(),
    );
  }

  @override
  String toString() {
    return 'NotificationActionHistory('
        'notificationId: $notificationId, '
        'assgineUserId: $assgineUserId, '
        'statusId: $statusId, '
        'statusName: $statusName, '
        'remark: $remark, '
        'createdBy: $createdBy, '
        'actionBy: $actionBy, '
        'actionOn: $actionOn, '
        'assginedUserName: $assginedUserName, '
        'updatedUserId: $updatedUserId, '
        'updatedUserName: $updatedUserName, '
        'updatedOn: $updatedOn'
        ')';
  }
}

List<LabelValue>? _mapList(dynamic list) {
  if (list == null) return null;
  return (list as List<dynamic>)
      .map((e) => LabelValue.fromJson(e as Map<String, dynamic>))
      .toList();
}

// LabelValue is re-exported for convenience by importing this file.

class CreateVMModel {
  final String? id;
  final int? notificationId;
  final String? notificationCode;
  final String? description;
  final int? natureOfWorkId;
  final int? notificationTypeId;
  final int? functionLocationId;
  final int? equipmentId;
  final String? actualFailureOccuranceOn;
  final int? assignedUserId;
  final bool? isServiceAffected;
  final bool? isOHEReq;
  final bool? isJointInspectionReq;
  final bool? isHardwareReplaced;
  final bool? isSICReq;
  final bool? isPTWReq;
  final int? failureTypeId;
  final int? deptId;
  final int? userStatus;
  final String? funcDescription;
  final String? locationName;
  final String? funcLocation;
  final String? equipmentName;
  final int? priorityId;
  final int? statusId;
  final String? priorityType;
  final String? mainStatusName;
  final String? failureRectificationDetails;
  final int? reasonForDelayId;
  final String? category;
  final String? deptCode;
  final int? locationTypeId;
  final int? corrNotificationTypeId;
  final String? trainRunningKm;
  final String? systemDowntime;

  final List<Map<String, dynamic>>? getObjectANDFaultList;
  final List<Map<String, dynamic>>? getObjectANDFaultActionList;
  final List<Map<String, dynamic>>? getObjectANDFaultRootCauseList;

  final String? remarkJe;
  final String? imagesPaths;
  final String? imagesPathsAfter;
  final String? imagesPathsRCA;

  final String? ptwNo;
  final int? trainDelayInMin;
  final int? trainDelayInNo;
  final int? noOfTranCancel;
  final int? noOfTranWithdrawal;
  final int? noOfTrainReplace;
  final bool? isPassengerDeboarding;
  final int? noofTrainDeboarded;
  final bool? isPassengerAffected;
  final int? noOfPassengerAffected;
  final String? trappedDuration;
  final String? rescuedDuration;
  final String? locationFailure;
  final String? actualFailureRectifiedDate;
  final String? failureAttendedDate;
  final String? failureType;
  final String? assignedUseeName;
  final String? underObservationDate;
  final String? systems;
  final String? subSystems;
  final String? failureRectificationJson;
  // field
  final int? frequency;

  // Filled when the failure came from an OCC failure (created by the Chief
  // Controller, assigned on by FMC / TPC / CSS / RSC). Shown read-only.
  final String? reportedTo;
  final String? otherRequestFrom;
  final String? occSystemName;
  final String? occSubLocation;
  final String? occLineName;
  final String? occTrainSetName;
  final String? occLocationText;
  final String? occTrainId;
  final String? occFailureCategory;
  final String? occTrainOperatorName;
  final String? occTrainReplacedRemark;
  final String? occTrainReplacedTime;
  final String? occWayOfRescue;



// fromJson


  CreateVMModel({
    this.id,
    this.notificationId,
    this.notificationCode,
    this.description,
    this.natureOfWorkId,
    this.notificationTypeId,
    this.functionLocationId,
    this.equipmentId,
    this.actualFailureOccuranceOn,
    this.assignedUserId,
    this.isServiceAffected,
    this.isOHEReq,
    this.isJointInspectionReq,
    this.isHardwareReplaced,
    this.isSICReq,
    this.isPTWReq,
    this.failureTypeId,
    this.deptId,
    this.userStatus,
    this.funcDescription,
    this.locationName,
    this.funcLocation,
    this.equipmentName,
    this.priorityId,
    this.statusId,
    this.priorityType,
    this.mainStatusName,
    this.failureRectificationDetails,
    this.reasonForDelayId,
    this.category,
    this.deptCode,
    this.remarkJe,
    this.imagesPaths,
    this.imagesPathsAfter,
    this.imagesPathsRCA,
    this.ptwNo,
    this.trainDelayInMin,
    this.trainDelayInNo,
    this.noOfTranCancel,
    this.noOfTranWithdrawal,
    this.noOfTrainReplace,
    this.isPassengerDeboarding,
    this.noofTrainDeboarded,
    this.isPassengerAffected,
    this.noOfPassengerAffected,
    this.trappedDuration,
    this.rescuedDuration,
    this.locationFailure,
    this.actualFailureRectifiedDate,
    this.failureAttendedDate,
    this.failureType,
    this.assignedUseeName,
    this.underObservationDate,
    this.systems,
    this.subSystems,
    this.locationTypeId,
    this.corrNotificationTypeId,
    this.getObjectANDFaultList,
    this.getObjectANDFaultActionList,
    this.getObjectANDFaultRootCauseList,
    this.failureRectificationJson,
    this.trainRunningKm,
    this.systemDowntime,
    // constructor
    this.frequency,
    this.reportedTo,
    this.otherRequestFrom,
    this.occSystemName,
    this.occSubLocation,
    this.occLineName,
    this.occTrainSetName,
    this.occLocationText,
    this.occTrainId,
    this.occFailureCategory,
    this.occTrainOperatorName,
    this.occTrainReplacedRemark,
    this.occTrainReplacedTime,
    this.occWayOfRescue,
  });

  static int? _asInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    return int.tryParse(value.toString());
  }

  static String? _asString(dynamic value) {
    if (value == null) return null;
    final text = value.toString().trim();
    return text.isEmpty ? null : text;
  }

  static bool? _asBool(dynamic value) {
    if (value is bool) return value;
    if (value is int) return value != 0;
    if (value is String) {
      final v = value.toLowerCase();
      if (v == 'yes' || v == 'true') return true;
      if (v == 'no' || v == 'false') return false;
    }
    return null;
  }

  factory CreateVMModel.fromJson(Map<String, dynamic> json) {
    debugPrint("CreateVMModel.fromJson: JSON keys = ${json.keys.toList()}");
    debugPrint("CreateVMModel.fromJson: systems=${json['systems']}, subSystems=${json['subSystems']}");
    debugPrint("CreateVMModel.fromJson: subsystem=${json['subsystem']}, Subsystem=${json['Subsystem']}");
    debugPrint("CreateVMModel.fromJson: subSystem=${json['subSystem']}, SubSystem=${json['SubSystem']}");
    debugPrint("CreateVMModel.fromJson: Full JSON sample = ${json.toString().substring(0, json.toString().length > 500 ? 500 : json.toString().length)}");
    return CreateVMModel(
      id: json['Id'] as String?,
      notificationId: CreateVMModel._asInt(json['notificationId']),
      notificationCode: json['notificationCode'] as String?,
      description: json['description'] as String?,
      natureOfWorkId: json['natureOfWorkId'] as int?,
      notificationTypeId: json['notificationTypeId'] as int?,
      functionLocationId: json['functionLocationId'] as int?,
      equipmentId: json['equipmentId'] as int?,
      actualFailureOccuranceOn: json['actualFailureOccuranceOn'] as String?,
      assignedUserId: json['assignedUserId'] as int?,
      isServiceAffected: json['isServiceAffected'] as bool?,
      isOHEReq: json['isOHEReq'] as bool?,
      isJointInspectionReq: json['isJointInspectionReq'] as bool?,
      isHardwareReplaced: json['isHardwareReplaced'] as bool?,
      isSICReq: json['isSICReq'] as bool?,
      isPTWReq: json['isPTWReq'] as bool?,
      failureTypeId: json['failureTypeId'] as int?,
      deptId: json['deptId'] as int?,
      userStatus: json['userStatus'] as int?,
      funcDescription: json['funcDescription'] as String?,
      locationName: _asString(json['locationName'] ?? json['locationTypeName']),
      funcLocation: _asString(
          json['funcLocation']
      ),
      equipmentName: _asString(json['equipmentName'] ?? json['equipmentNo']),
      priorityId: json['priorityId'] as int?,
      statusId: json['statusId'] as int?,
      priorityType: json['priorityType'] as String?,
      mainStatusName: json['mainStatusName'] as String?,
      failureRectificationDetails: json['failureRectificationDetails'] as String?,
      reasonForDelayId: json['reasonForDelayId'] as int?,
      category: json['category'] as String?,
      deptCode: json['deptCode'] as String?,
      remarkJe: json['remark_JE'] as String?,
      imagesPaths: json['imagesPaths'] as String?,
      imagesPathsAfter: json['imagesPathsAfter'] as String?,
      imagesPathsRCA: json['imagesPathsRCA'] as String?,
      ptwNo: json['ptwNo'] as String?,
      trainDelayInMin: json['trainDelayInMin'] as int?,
      trainDelayInNo: json['trainDelayInNo'] as int?,
      noOfTranCancel: json['noOfTranCancel'] as int?,
      noOfTranWithdrawal: json['noOfTranWithdrawal'] as int?,
      noOfTrainReplace: json['noOfTrainReplace'] as int?,
      isPassengerDeboarding: json['isPassengerDeboarding'] as bool?,
      noofTrainDeboarded: _asInt(json['noofTrainDeboarded'] ?? json['NoofTrainDeboarded']),
      isPassengerAffected: _asBool(
        json['isPassengerAffected'] ?? json['IsPassengerAffected'] ?? json['passengerAffected'],
      ),
      noOfPassengerAffected: _asInt(
        json['noOfPassengerAffected'] ??
            json['NoOfPassengerAffected'] ??
            json['numberOfPassengerAffected'] ??
            json['NumberOfPassengerAffected'],
      ),
      trappedDuration: _asString(json['trappedDuration'] ?? json['TrappedDuration']),
      rescuedDuration: _asString(
        json['rescuedDuration'] ??
            json['RescuedDuration'] ??
            json['rescusedDuration'] ??
            json['RescusedDuration'],
      ),
      locationFailure: json['locationFailure'] as String?,
      actualFailureRectifiedDate: json['actualFailureRectifiedDate'] as String?,
      failureAttendedDate: json['failureAttendedDate'] as String?,
      failureType: json['failureType'] as String?,
      assignedUseeName: json['assignedUseeName'] as String?,
      underObservationDate: json['underObservationDate'] as String?,
      systems: _asString(json['systems'] ?? json['Systems'] ?? json['system'] ?? json['System']),
      subSystems: _asString(json['subSystems'] ?? json['SubSystems'] ?? json['subsystem'] ?? json['Subsystem'] ?? json['subSystem'] ?? json['SubSystem']),
      locationTypeId: json['locationTypeId'] as int?,
      corrNotificationTypeId: json['corr_NotificationTypeId'] as int?,
      getObjectANDFaultList: json['getObjectANDFaultList'] != null
          ? (json['getObjectANDFaultList'] as List).map((e) => e as Map<String, dynamic>).toList()
          : null,
      getObjectANDFaultActionList: json['getObjectANDFaultActionList'] != null
          ? (json['getObjectANDFaultActionList'] as List).map((e) => e as Map<String, dynamic>).toList()
          : null,
      getObjectANDFaultRootCauseList: json['getObjectANDFaultRootCauseList'] != null
          ? (json['getObjectANDFaultRootCauseList'] as List).map((e) => e as Map<String, dynamic>).toList()
          : null,
      failureRectificationJson: _parseRcaJson(json['FailureRectificationJson'] ?? json['failureRectificationJson']),

      trainRunningKm: _asString(json['trainRunningKM']),
      systemDowntime: _asString(json['systemDowntime']),
      frequency: _asInt(json['frequency'] ?? json['Frequency']),
      reportedTo: _asString(json['reportedTo'] ??
          json['reportedToName'] ??
          json['occReportedTo'] ??
          json['occReportedToName']),
      otherRequestFrom: _asString(json['otherRequestFrom']),
      occSystemName: _asString(json['systemNameOCC']),
      occSubLocation: _asString(json['subLocationOCC']),
      occLineName: _asString(json['occLineIdName'] ?? json['occLineName']),
      occTrainSetName:
      _asString(json['occTrainSetName'] ?? json['occTrainSetIdName']),
      occLocationText: _asString(json['occLocationText']),
      occTrainId: _asString(json['trainNumberOCC']),
      occFailureCategory: _asString(json['occFailureCategoryType']),
      occTrainOperatorName: _asString(json['occTrainOpeartorName']),
      occTrainReplacedRemark: _asString(json['occTrainReplacedWithRemark']),
      occTrainReplacedTime: _asString(json['occTrainReplacedWithTime']),
      occWayOfRescue: _asString(json['occWayOfRescueRemark']),
    );
  }

  static String? _parseRcaJson(dynamic value) {
    if (value == null) return null;
    if (value is String) return value;
    if (value is List) return jsonEncode(value);
    return null;
  }
}

class NotificationHistory {
  final int? historyId;
  final int? createdById;
  final String? description;
  final String? createdBy;
  final String? createdOn;

  NotificationHistory({
    this.historyId,
    this.createdById,
    this.description,
    this.createdBy,
    this.createdOn,
  });

  factory NotificationHistory.fromJson(Map<String, dynamic> json) {
    return NotificationHistory(
      historyId: json['historyId'] as int?,
      createdById: json['createdById'] as int?,
      description: json['description']?.toString(),
      createdBy: json['createdBy']?.toString(),
      createdOn: json['createdOn']?.toString(),
    );
  }
}